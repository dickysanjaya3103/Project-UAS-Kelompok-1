package Kantin;

public class Makanan extends Barang {
    public Makanan(String nama, String kode, double harga) {
        super(nama, kode, harga);
    }

    @Override
    public String toString() {
        return "[Makanan] " + super.toString();
    }
}