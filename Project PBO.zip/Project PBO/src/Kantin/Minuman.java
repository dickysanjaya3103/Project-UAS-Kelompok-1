package Kantin;

public class Minuman extends Barang {
    public Minuman(String nama, String kode, double harga) {
        super(nama, kode, harga);
    }

    @Override
    public String toString() {
        return "[Minuman] " + super.toString();
    }
}