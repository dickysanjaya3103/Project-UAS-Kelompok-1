package Kantin;

import java.util.ArrayList;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan Nama: ");
        String nama = input.nextLine();
        System.out.print("Masukkan NIM: ");
        String nim = input.nextLine();
        System.out.print("Masukkan Prodi: ");
        String prodi = input.nextLine();

        System.out.println("\n=== Data Mahasiswa ===");
        System.out.println("Nama : " + nama);
        System.out.println("NIM  : " + nim);
        System.out.println("Prodi: " + prodi);
        System.out.println("======================");

        ArrayList<Barang> kantin = new ArrayList<>();
        kantin.add(new Makanan("Nasi Goreng", "MKN001", 15.0));
        kantin.add(new Makanan("Nasi Pecel", "MKN002", 6.0));
        kantin.add(new Minuman("Es Teh", "MIN001", 3.0));
        kantin.add(new Minuman("Es Jeruk", "MIN002", 3.0));

        int pilihan;
        ArrayList<Barang> sorted = new ArrayList<>(kantin);

        do {
            System.out.println("\n=== Menu ===");
            System.out.println("1. Daftar Menu");
            System.out.println("2. Daftar Setelah Sorting");
            System.out.println("3. Edit Menu");
            System.out.println("4. Cari Menu");
            System.out.println("0. Keluar");
            System.out.print("Pilih: ");
            pilihan = input.nextInt();
            input.nextLine();

            switch (pilihan) {
                case 1:
                    System.out.println(">> Menu:");
                    kantin.forEach(System.out::println);
                    break;
                case 2:
                    sorted = new ArrayList<>(kantin);
                    bubbleSortHarga(sorted);
                    System.out.println(">> Setelah Sorting:");
                    sorted.forEach(System.out::println);
                    break;
                case 3:
                    System.out.print("Indeks yang ingin diubah: ");
                    int i = input.nextInt(); input.nextLine();
                    if (i >= 0 && i < kantin.size()) {
                        System.out.print("Nama baru: ");
                        String n = input.nextLine();
                        System.out.print("Kode baru: ");
                        String k = input.nextLine();
                        System.out.print("Harga baru: ");
                        double h = input.nextDouble(); input.nextLine();
                        kantin.get(i).setNama(n);
                        kantin.get(i).setKode(k);
                        kantin.get(i).setHarga(h);
                        System.out.println(">> Menu diubah.");
                    } else {
                        System.out.println(">> Indeks tidak valid.");
                    }
                    break;
                case 4:
                    System.out.print("Masukkan kode: ");
                    String kode = input.nextLine();
                    Barang hasil = Barang.cariBarang(kantin, kode);
                    if (hasil != null) System.out.println(">> " + hasil);
                    else System.out.println(">> Tidak ditemukan.");
                    break;
                case 0:
                    System.out.println(">> Keluar.");
                    break;
                default:
                    System.out.println(">> Pilihan tidak valid.");
            }

        } while (pilihan != 0);

        input.close();
    }

    public static void bubbleSortHarga(ArrayList<Barang> daftar) {
        for (int i = 0; i < daftar.size() - 1; i++) {
            for (int j = 0; j < daftar.size() - 1 - i; j++) {
                if (daftar.get(j).getHarga() > daftar.get(j + 1).getHarga()) {
                    Barang temp = daftar.get(j);
                    daftar.set(j, daftar.get(j + 1));
                    daftar.set(j + 1, temp);
                }
            }
        }
    }
}