package Kantin;
//Kelas Induk
public abstract class Barang {
    protected String nama;
    protected String kode;
    protected double harga;

    public Barang(String nama, String kode, double harga) {
        this.nama = nama;
        this.kode = kode;
        this.harga = harga;
    }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getKode() { return kode; }
    public void setKode(String kode) { this.kode = kode; }

    public double getHarga() { return harga; }
    public void setHarga(double harga) { this.harga = harga; }

    @Override
    public String toString() {
        return "Nama: " + nama + ", Kode: " + kode + ", Harga: Rp" + harga;
    }

    public static Barang cariBarang(java.util.ArrayList<Barang> list, String kode) {
        for (Barang b : list) {
            if (b.getKode().equalsIgnoreCase(kode)) {
                return b;
            }
        }
        return null;
    }
}